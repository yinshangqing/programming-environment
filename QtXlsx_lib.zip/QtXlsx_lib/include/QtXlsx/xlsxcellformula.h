#include "../../../QtXlsxWriter-master/src/xlsx/xlsxcellformula.h"
