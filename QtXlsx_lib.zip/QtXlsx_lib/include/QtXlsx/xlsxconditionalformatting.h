#include "../../../QtXlsxWriter-master/src/xlsx/xlsxconditionalformatting.h"
