#include "../../../QtXlsxWriter-master/src/xlsx/xlsxcell.h"
