#include "../../../QtXlsxWriter-master/src/xlsx/xlsxrichstring.h"
