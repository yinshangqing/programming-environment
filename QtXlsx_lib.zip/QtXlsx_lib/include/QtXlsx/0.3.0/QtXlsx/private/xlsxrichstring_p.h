#include "../../../../../../QtXlsxWriter-master/src/xlsx/xlsxrichstring_p.h"
