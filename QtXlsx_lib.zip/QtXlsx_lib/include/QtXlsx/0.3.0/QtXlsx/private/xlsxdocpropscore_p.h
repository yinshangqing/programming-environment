#include "../../../../../../QtXlsxWriter-master/src/xlsx/xlsxdocpropscore_p.h"
