#include "../../../../../../QtXlsxWriter-master/src/xlsx/xlsxcolor_p.h"
